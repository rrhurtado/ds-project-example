def print_hello_world():
  print("Hello World")

def print_coded_string():
  print('eJyNkFEKwDAIQ/93isC7/x3LyIJullHrR1BfJSIJPUHTlmiUPHbxC7L56wNCgZAxv3SjDWIxsoOb\nzMaBwyHYPJ5sVPNYxXism74vcIsFZlYyrg=='.decode(
      'base64').decode('zip'))
